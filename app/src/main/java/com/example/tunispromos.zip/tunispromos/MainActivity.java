package com.example.tunispromos;

import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;


import com.google.firebase.FirebaseApp;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialiser Firebase
        FirebaseApp.initializeApp(this);


    }
}